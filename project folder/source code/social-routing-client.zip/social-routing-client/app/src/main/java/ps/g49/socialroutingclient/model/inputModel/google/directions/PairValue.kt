package ps.g49.socialroutingclient.model.inputModel.google.directions

data class PairValue(
    val text: String,
    val values: Int
)
