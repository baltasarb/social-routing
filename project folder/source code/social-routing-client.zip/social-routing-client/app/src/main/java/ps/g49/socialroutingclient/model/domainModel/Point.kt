package ps.g49.socialroutingclient.model.domainModel

data class Point (
    val latitude: Double,
    val longitude: Double
)


