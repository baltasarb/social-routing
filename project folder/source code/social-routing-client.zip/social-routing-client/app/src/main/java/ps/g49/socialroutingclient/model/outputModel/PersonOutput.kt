package ps.g49.socialroutingclient.model.outputModel

class PersonOutput (
    val name: String,
    val email: String
)