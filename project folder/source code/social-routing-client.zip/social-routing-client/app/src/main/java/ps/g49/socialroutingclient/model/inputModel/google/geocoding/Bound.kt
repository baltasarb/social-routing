package ps.g49.socialroutingclient.model.inputModel.google.geocoding

data class Bound(
    val northeast: PointGeocoding,
    val southwest: PointGeocoding
)