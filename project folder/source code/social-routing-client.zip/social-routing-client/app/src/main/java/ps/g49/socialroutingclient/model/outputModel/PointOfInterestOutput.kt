package ps.g49.socialroutingclient.model.outputModel

data class PointOfInterestOutput (
    val identifier: String,
    val latitude: Double,
    val longitude: Double
)