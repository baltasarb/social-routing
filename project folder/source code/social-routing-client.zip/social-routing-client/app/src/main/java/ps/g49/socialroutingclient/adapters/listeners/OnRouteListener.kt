package ps.g49.socialroutingclient.adapters.listeners

interface OnRouteListener {
    fun onRouteClick(position: Int)
}