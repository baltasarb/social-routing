package ps.g49.socialroutingclient.model.inputModel.google.geocoding

data class PointGeocoding(
    val lat: Double,
    val lng: Double
)