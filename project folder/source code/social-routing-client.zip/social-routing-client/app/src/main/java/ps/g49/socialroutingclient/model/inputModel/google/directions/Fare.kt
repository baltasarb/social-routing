package ps.g49.socialroutingclient.model.inputModel.google.directions

data class Fare (
    val currency: String,
    val value: Int,
    val text: String
)
