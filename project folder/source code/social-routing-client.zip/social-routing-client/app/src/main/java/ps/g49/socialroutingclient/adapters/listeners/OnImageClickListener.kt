package ps.g49.socialroutingclient.adapters.listeners

interface OnImageClickListener {
    fun onClick(position: Int)
}