package ps.g49.socialroutingclient.model.outputModel

data class AuthorizationOutput (
    val idTokenString: String
)