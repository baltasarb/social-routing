package ps.g49.socialroutingclient.model.domainModel

data class Photo(
    val photoReference: String,
    val maxHeight: Int,
    val maxWidth: Int
)