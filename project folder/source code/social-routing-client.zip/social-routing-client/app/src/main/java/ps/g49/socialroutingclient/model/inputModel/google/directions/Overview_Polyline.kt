package ps.g49.socialroutingclient.model.inputModel.google.directions

data class Overview_Polyline (
    val points: String
)
