package ps.g49.socialroutingclient.model.inputModel.socialRouting

import ps.g49.socialroutingclient.model.domainModel.Category

data class CategoryCollectionInput(
    val categories: List<Category>
)