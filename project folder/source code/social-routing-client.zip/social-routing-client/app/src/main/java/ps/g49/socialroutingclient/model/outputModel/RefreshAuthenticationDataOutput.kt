package ps.g49.socialroutingclient.model.outputModel

data class RefreshAuthenticationDataOutput(
    val refreshToken: String
)