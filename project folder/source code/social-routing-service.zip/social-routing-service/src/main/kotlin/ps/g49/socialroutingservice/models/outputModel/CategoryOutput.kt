package ps.g49.socialroutingservice.models.outputModel

data class CategoryOutput(
        val name: String
)