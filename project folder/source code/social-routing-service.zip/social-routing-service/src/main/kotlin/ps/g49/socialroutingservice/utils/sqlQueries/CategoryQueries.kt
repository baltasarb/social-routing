package ps.g49.socialroutingservice.utils.sqlQueries

class CategoryQueries {

    companion object {
        const val SELECT_MANY = "SELECT Name FROM Category;"
    }

}