package ps.g49.socialroutingservice.models.inputModel

data class RefreshAuthenticationDataInput(
        val refreshToken: String
)