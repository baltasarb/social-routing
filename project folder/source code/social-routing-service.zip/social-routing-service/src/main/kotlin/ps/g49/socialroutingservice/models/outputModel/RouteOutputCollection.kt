package ps.g49.socialroutingservice.models.outputModel

data class RouteOutputCollection(
        val routes: List<RouteOutput>
)