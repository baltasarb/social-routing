package ps.g49.socialroutingservice.mappers.outputMappers

import ps.g49.socialroutingservice.mappers.Mapper

interface OutputMapper<T, R> : Mapper<T, R>