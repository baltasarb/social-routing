package ps.g49.socialroutingservice.models.domainModel

data class Category(
        val name: String
) {
    override fun toString(): String {
        return name
    }
}

