package ps.g49.socialroutingservice.models.domainModel

data class PointOfInterest(
        val identifier: String, //name
        val latitude: Double,
        val longitude: Double
)