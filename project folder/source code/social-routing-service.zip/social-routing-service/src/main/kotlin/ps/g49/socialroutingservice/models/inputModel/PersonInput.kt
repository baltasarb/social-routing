package ps.g49.socialroutingservice.models.inputModel

data class PersonInput(
        val rating: Double? = null
)