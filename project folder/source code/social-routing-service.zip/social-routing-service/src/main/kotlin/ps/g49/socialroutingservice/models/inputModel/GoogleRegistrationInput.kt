package ps.g49.socialroutingservice.models.inputModel

data class GoogleRegistrationInput(
        val idTokenString: String
)