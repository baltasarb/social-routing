package ps.g49.socialroutingservice.models.domainModel

data class GeographicPoint(
        var latitude: Double,
        var longitude: Double
)