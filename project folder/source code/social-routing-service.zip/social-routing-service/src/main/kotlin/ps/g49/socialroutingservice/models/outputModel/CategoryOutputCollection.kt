package ps.g49.socialroutingservice.models.outputModel

data class CategoryOutputCollection(
        val categories: List<CategoryOutput>
)