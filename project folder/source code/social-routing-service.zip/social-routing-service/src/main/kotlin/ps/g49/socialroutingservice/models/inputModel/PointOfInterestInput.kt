package ps.g49.socialroutingservice.models.inputModel

data class PointOfInterestInput(
        val identifier: String, //name
        val latitude: Double,
        val longitude: Double
)