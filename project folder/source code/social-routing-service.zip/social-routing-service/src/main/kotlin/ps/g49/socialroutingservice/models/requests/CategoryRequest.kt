package ps.g49.socialroutingservice.models.requests

data class CategoryRequest(
        val name: String
)