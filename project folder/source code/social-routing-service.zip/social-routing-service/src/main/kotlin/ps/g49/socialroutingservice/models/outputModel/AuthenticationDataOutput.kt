package ps.g49.socialroutingservice.models.outputModel

class AuthenticationDataOutput(
        val accessToken: String,
        val refreshToken: String
)