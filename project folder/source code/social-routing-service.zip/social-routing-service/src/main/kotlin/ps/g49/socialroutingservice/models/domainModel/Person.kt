package ps.g49.socialroutingservice.models.domainModel

data class Person(
        val identifier: Int? = null,
        val rating: Double? = null
)